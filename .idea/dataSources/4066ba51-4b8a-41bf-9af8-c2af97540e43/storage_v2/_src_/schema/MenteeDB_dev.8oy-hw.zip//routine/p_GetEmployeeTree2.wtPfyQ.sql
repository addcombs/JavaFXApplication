create procedure p_GetEmployeeTree2(IN parentId int, IN termCode char(3), IN roleId int, IN lvl int)
BEGIN
	DECLARE eol INT DEFAULT FALSE;
	DECLARE inherit_id INT(10);
	DECLARE inherit_cur CURSOR FOR SELECT e.id FROM employees e WHERE e.reg_supervisor = parentId and e.deleted = '0' order by e.id;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET eol = TRUE;

	IF lvl = 0 THEN
		SET max_sp_recursion_depth=10;
	END IF;

    CREATE TEMPORARY TABLE IF NOT EXISTS employee_tree LIKE employees;
	
	SET @sqlInsert = "INSERT INTO employee_tree SELECT DISTINCT e.id,e.last_name,e.first_name,e.terminal_id,e.status,e.scheduled_start,
	e.scheduled_end,e.scheduled_days,e.reg_plan_type,e.reg_supervisor,e.last_update_user,e.last_update_timestamp, e.deleted FROM employees e ";
	
	IF roleId > 0 THEN
		SET @sqlInsert = CONCAT(@sqlInsert, "INNER JOIN emp_roles er ON e.id = er.emp_id ");
	END IF;
	SET @sqlInsert = CONCAT(@sqlInsert, "WHERE e.id = ? AND e.deleted = '0' ");
	IF roleId > 0 THEN
		SET @sqlInsert = CONCAT(@sqlInsert, "AND er.role_id = ? AND er.deleted = '0' ");
	END IF;
	IF termCode <> '' THEN
		SET @sqlInsert = CONCAT(@sqlInsert, "AND e.terminal_id = ?");
	END IF;

	SET @parentId = parentId;
	SET @roleId = roleId;
	SET @termCode = termCode;

	PREPARE insertStatement FROM @sqlInsert;
	IF roleId = 0 AND termCode = '' THEN
		EXECUTE insertStatement USING @parentId;
	ELSE 
		IF roleId > 0 and termCode = '' THEN
			EXECUTE insertStatement USING @parentId, @roleId;
		ELSE
			IF roleId = 0 and termCode <> '' THEN
				EXECUTE insertStatement USING @parentId , @termCode;
			ELSE
				EXECUTE insertStatement USING @parentId , @roleId, @termCode;
			END IF;
		END IF;
	END IF;

	OPEN inherit_cur;
	inherited: LOOP
		FETCH inherit_cur INTO inherit_id;
		IF eol THEN
			CLOSE inherit_cur;
			LEAVE inherited;
		ELSE
			CALL p_GetEmployeeTree2(inherit_id, termCode, roleId, 1);
		END IF;
	END LOOP inherited;

	IF lvl = 0 THEN
		SET @sqlSelect = "SELECT * FROM employee_tree";
		PREPARE selectStatement FROM @sqlSelect;
		EXECUTE selectStatement;
	END IF;
END;

