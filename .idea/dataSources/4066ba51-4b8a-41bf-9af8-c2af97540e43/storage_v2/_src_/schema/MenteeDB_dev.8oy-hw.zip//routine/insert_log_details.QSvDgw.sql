create procedure insert_log_details(IN p_class varchar(30), IN p_method varchar(60), IN p_server_ip varchar(16),
                                    IN p_client_server varchar(16), IN p_start_date timestamp,
                                    IN p_total_time_ns bigint)
BEGIN
    DECLARE v_id INT;
        
    
    SET @v_id = null;
    
    SET @v_class = p_class;
    SET @v_method = p_method;
    SET @v_server_ip = p_server_ip;
    SET @v_client_server = p_client_server;
    SET @v_start_date = p_start_date;
    SET @v_total_time_ns = p_total_time_ns;


	SET @sqlInsertCourseMethods = "INSERT INTO log_class_methods_index (class,method) VALUES (?,?)";
        
	SET @sqlGetCourseMethod = "SELECT id INTO @v_id FROM log_class_methods_index WHERE class=? AND method=?";
    
    SET @sqlInsertLogData = "INSERT INTO log_method_details 
		(class_methods_fk, client_server, server_ip, start_date, total_time_ns) VALUES (?,?,?,?,?)";   
        
	PREPARE retrieveId FROM @sqlGetCourseMethod;
    EXECUTE retrieveId USING @v_class,@v_method;
    
    IF @v_id IS NULL THEN
    
		    
		START TRANSACTION;
		PREPARE insertMethod FROM @sqlInsertCourseMethods;
		EXECUTE insertMethod USING @v_class,@v_method;
		DEALLOCATE PREPARE insertMethod;  
        COMMIT;
        

        EXECUTE retrieveId USING @v_class,@v_method;
    END IF;
    
    DEALLOCATE PREPARE retrieveId; 
        
    PREPARE insertLog FROM @sqlInsertLogData;
    EXECUTE insertLog USING @v_id,@v_client_server,@v_server_ip,@v_start_date,@v_total_time_ns;
    DEALLOCATE PREPARE insertLog;
   
END;

