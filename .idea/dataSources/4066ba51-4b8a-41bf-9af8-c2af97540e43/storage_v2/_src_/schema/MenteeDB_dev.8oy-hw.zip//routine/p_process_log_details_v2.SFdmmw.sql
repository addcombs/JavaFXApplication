create procedure p_process_log_details_v2(IN p_class varchar(50), IN p_method varchar(50), IN p_terminal int,
                                          IN p_server int, IN p_start_date timestamp, IN p_total_time_ns bigint,
                                          IN p_table int)
BEGIN
	DECLARE v_id INT;
	DECLARE v_avg BIGINT;
	DECLARE v_count INT;
	DECLARE v_min BIGINT;
	DECLARE v_max BIGINT;
	DECLARE v_log_id INT;
	DECLARE v_method_id INT;
	DECLARE v_terminal_id INT;
	DECLARE v_server_id INT;
        
    
   SET @v_id = null;
   SET @v_avg = null;
   SET @v_count = null;
   SET @v_min = null;
   SET @v_max = null;
   SET @v_log_id = null;
   SET @v_method_id = null;
    
   SET @v_class = p_class;
   SET @v_method = p_method;
   SET @v_terminal_id = p_terminal;
   SET @v_server_id = p_server;
   SET @v_start_date = p_start_date;
   SET @v_total_time_ns = p_total_time_ns;
   SET @v_table = p_table;

	SET @sqlSelectCourseMethods = "SELECT id INTO @v_method_id FROM log_class_methods_index WHERE class=? AND method=?";
	SET @sqlInsertCourseMethods = "INSERT IGNORE INTO log_class_methods_index (class,method) VALUES (?,?)";
	SET @sqlInsertDetailInfo = "INSERT IGNORE INTO log_type_details (class_method_id,terminal_id,server_id) VALUES (?,?,?)";
        
	SET @sqlGetCourseMethod = "SELECT log_type_details.id INTO @v_id FROM log_type_details 
				INNER JOIN log_class_methods_index ON log_class_methods_index.id=log_type_details.class_method_id 
				WHERE log_class_methods_index.class=? AND log_class_methods_index.method=? AND log_type_details.terminal_id =? AND log_type_details.server_id=?";
				
	SET @sqlGetCourseMethodFromIds = "SELECT id INTO @v_id FROM log_type_details 
				WHERE class_method_id=? AND terminal_id=? AND server_id=?";
   
	SET @sqlSelectLogData = CONCAT("SELECT id, avg_time_ns_tmp, avg_count_tmp, max_time_tmp, min_time_tmp
				INTO @v_log_id, @v_avg, @v_count, @v_max, @v_min 
				FROM log_method_processed_details",@v_table," 
				WHERE class_methods_fk=? AND start_date=?");
	 
   SET @sqlInsertLogData = CONCAT("INSERT INTO log_method_processed_details",@v_table," 
				(class_methods_fk,  start_date, avg_time_ns_tmp, avg_count_tmp,max_time_tmp,min_time_tmp) VALUES (?,?,?,1,?,?)");   
		
	SET @sqlUpdateLogData = CONCAT("UPDATE log_method_processed_details",@v_table,"
				SET avg_time_ns_tmp=?, avg_count_tmp=?, max_time_tmp=?, min_time_tmp=?
				WHERE id=?");
							
        
	PREPARE retrieveId FROM @sqlGetCourseMethod;
   EXECUTE retrieveId USING @v_class,@v_method,@v_terminal_id,@v_server_id;
   DEALLOCATE PREPARE retrieveId; 
    
   IF @v_id IS NULL THEN
      
      PREPARE selectMethod FROM @sqlSelectCourseMethods;
      EXECUTE selectMethod USING @v_class,@v_method;
      
      IF @v_method_id IS NULL THEN
			START TRANSACTION;
			PREPARE insertMethod FROM @sqlInsertCourseMethods;
			EXECUTE insertMethod USING @v_class,@v_method;
			DEALLOCATE PREPARE insertMethod;  
	      COMMIT;
	      
	      EXECUTE selectMethod USING @v_class,@v_method;
      END IF;
      
      DEALLOCATE PREPARE selectMethod;
      
   	START TRANSACTION;
		PREPARE insertType FROM @sqlInsertDetailInfo;
		EXECUTE insertType USING @v_method_id,@v_terminal_id,@v_server_id;
		DEALLOCATE PREPARE insertType;  
   	COMMIT;
      
      PREPARE retrieveId FROM @sqlGetCourseMethodFromIds;
   	EXECUTE retrieveId USING @v_method_id,@v_terminal_id,@v_server_id;
      DEALLOCATE PREPARE retrieveId; 
      
   END IF;
   
	PREPARE selectLogData FROM @sqlSelectLogData;
	EXECUTE selectLogData USING @v_id,@v_start_date;
	DEALLOCATE PREPARE selectLogData;
	
	IF @v_log_id IS NULL THEN
		PREPARE insertLogData FROM @sqlInsertLogData;
		EXECUTE insertLogData USING @v_id,@v_start_date,@v_total_time_ns,@v_total_time_ns,@v_total_time_ns;
		DEALLOCATE PREPARE insertLogData;
	ELSE
		SET @v_avg = TRUNCATE(@v_avg + ((@v_total_time_ns-@v_avg)*(1/(@v_count+1))),0);
		SET @v_count = @v_count + 1;
		SET @v_max = GREATEST(@v_max,@v_total_time_ns);
		SET @v_min = LEAST(@v_min,@v_total_time_ns);
	
		PREPARE updateLogData FROM @sqlUpdateLogData;
		EXECUTE updateLogData USING @v_avg,@v_count,@v_max,@v_min,@v_log_id;
		DEALLOCATE PREPARE updateLogData;
	END IF;
END;

